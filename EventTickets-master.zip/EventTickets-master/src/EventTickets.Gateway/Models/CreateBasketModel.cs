﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EventTickets.Gateway.Models
{
    public class CreateBasketModel
    {
        public Guid UserId { get; set; }
    }
}
